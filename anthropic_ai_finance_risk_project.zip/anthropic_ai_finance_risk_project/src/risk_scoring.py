"""AI risk scoring model for financial services use cases."""

from pathlib import Path
import pandas as pd

WEIGHTS = {
    "financial_impact": 0.15,
    "operational_complexity": 0.15,
    "regulatory_sensitivity": 0.25,
    "data_privacy_exposure": 0.20,
    "explainability_requirement": 0.15,
    "human_oversight_requirement": 0.10,
}


def calculate_weighted_score(row: pd.Series) -> float:
    """Calculate a weighted AI risk score from 1 to 5."""
    return sum(row[column] * weight for column, weight in WEIGHTS.items())


def categorise_risk(score: float) -> str:
    """Convert numerical score into a risk category."""
    if score >= 4.0:
        return "High"
    if score >= 3.0:
        return "Medium"
    return "Low"


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    data_path = project_root / "data" / "ai_finance_use_cases.csv"

    df = pd.read_csv(data_path)
    df["weighted_risk_score"] = df.apply(calculate_weighted_score, axis=1).round(2)
    df["risk_category"] = df["weighted_risk_score"].apply(categorise_risk)

    ranked = df.sort_values("weighted_risk_score", ascending=False)

    print("\nAI Finance Use Case Risk Ranking\n")
    print(ranked[["use_case", "area", "weighted_risk_score", "risk_category"]].to_string(index=False))

    output_path = project_root / "data" / "ai_finance_use_cases_scored.csv"
    ranked.to_csv(output_path, index=False)

    print(f"\nScored output saved to: {output_path}")


if __name__ == "__main__":
    main()
